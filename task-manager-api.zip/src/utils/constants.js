module.exports = {
  TASK_STATUSES: ['pending', 'in_progress', 'completed']
};